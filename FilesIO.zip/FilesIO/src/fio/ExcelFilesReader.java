package fio;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.caciopee.genie.soa.client.result.BeanObject;
import com.caciopee.genie.soa.client.result.GenieList;

public class ExcelFilesReader implements FilesReader {
	private String pathToFile;
	private FileInputStream fileInputStream;

	public ExcelFilesReader(String ptf) {
		this.pathToFile = ptf;
	}

	@Override
	public List<BeanObject> readContents() throws ParseException {
		System.out.println("read excel file ["+this.pathToFile+"]");
		if (this.fileInputStream == null) {
			this.openFile();
		}
		System.out.println("read excel file ["+this.pathToFile+"] => file opend");
		Workbook workbook = null;
		try {
			workbook = new XSSFWorkbook(this.fileInputStream);
		} catch (IOException ee) {
			System.out.println(ee.getMessage());
		}
		
		System.out.println("read excel file ["+this.pathToFile+"] => XSSFWorkbook opend");

		Sheet sheet = workbook.getSheetAt(0);

		int lastRow = sheet.getLastRowNum();
		
		System.out.println("read excel file ["+this.pathToFile+"] => lastRow = "+lastRow);

		// Looping over entire row
		List<String> headers = new GenieList<>();
		List<String> types = new GenieList<>();
		List<BeanObject> datas = new GenieList<>();
		CellExcel cellExcel = null;
		BeanObject objData = null;
		for1: for (int lineRow = 0; lineRow <= lastRow; lineRow++) {

			Row row = sheet.getRow(lineRow);
			if (row == null) {
				break for1;
			}
			
			int lastCell = row.getLastCellNum();
			System.out.println("read excel file ["+this.pathToFile+"] => lastRow = "+lastRow + " row ["+lineRow+"] lastCell ["+lastCell+"]");
			objData = new BeanObject();
			for2: for (int cellNbr = 0; cellNbr < lastCell; cellNbr++) {
				cellExcel = new CellExcel(row.getCell(cellNbr));
				// check if all headers exist
				if (lineRow == 0) {
					if (cellExcel.getCell() == null || cellExcel.getCell().getStringCellValue() == null || cellExcel.getCell().getStringCellValue().isEmpty()) {
						System.out.println("no.header");
						System.out.println("[READ DATA FROM EXCEL] file " + this.pathToFile + " with header null");
						break for1;
					}
					headers.add(cellExcel.getCell().toString());
					continue for2;
				}
				// check if all types exist
				if (lineRow == 1) {
					if (cellExcel.getCell() == null || cellExcel.getCell().getStringCellValue() == null || cellExcel.getCell().getStringCellValue().isEmpty()) {
						System.out.println("no.type");
						System.out.println("[READ DATA FROM EXCEL] file " + this.pathToFile + " with header null");
						break for1;
					}
					types.add(cellExcel.getCell().toString());
					continue for2;
				}
				if (cellExcel.getCell() == null) {
					continue for2;
				}
				if (lineRow < 2) {
					continue for2;
				}
				if (objData == null) {
					objData = new BeanObject();
				}
				
				if (headers.get(cellNbr).split("\\.").length > 1) {
					setValueWithComplicatedMapping(objData, headers.get(cellNbr), cellExcel.getValueByType(types.get(cellNbr)));
					//objData.fillPathValue(headers.get(cellNbr), cellExcel.getValueByType(types.get(cellNbr)));
				} else {
					objData.put(headers.get(cellNbr), cellExcel.getValueByType(types.get(cellNbr)));
				}
			}
			if (lineRow < 2) {
				continue;
			}
			datas.add(objData);
			//System.out.println("read excel file ["+this.pathToFile+"] => lastRow = "+lastRow + " objData "+objData.toJson());
		}
		//System.out.println("****** read excel file ["+this.pathToFile+"] => lastRow = "+lastRow + " datas "+datas.size());
		return datas;
	}

	@Override
	public void openFile() {
		try {
			this.fileInputStream = new FileInputStream(this.pathToFile);
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		}

	}

	private void setValueWithComplicatedMapping(BeanObject objData, String mapping, Object objValue) {
		BeanObject firstObject = null;
		if (mapping.contains(".") && mapping.split("\\.").length > 1) {
			String[] tabMapping = mapping.split("\\.");
			String accumulatedMapping = "";
			String currentMapping = null;
			for (int i = 0; i < tabMapping.length; i++) {
				if (i == tabMapping.length - 1) {
					BeanObject lastBeanOfTheMapping = null;
					// last part of the mapping
					for (int j = 0; j < i; j++) {
						if (j == 0) {
							lastBeanOfTheMapping = objData.getBo(tabMapping[0]);
							continue;
						}
						lastBeanOfTheMapping = lastBeanOfTheMapping.getBo(tabMapping[j]);

					}

					lastBeanOfTheMapping.put(tabMapping[i], objValue);
					continue;
				}
				if (accumulatedMapping.isEmpty()) {
					currentMapping = tabMapping[i];
				} else {
					currentMapping = accumulatedMapping + "." + tabMapping[i];
				}
				if (objData.getBo(currentMapping) == null) {
					objData.put(currentMapping, new BeanObject());
				}
				accumulatedMapping = currentMapping;
			}

		}
	}

	@Override
	public BeanObject readContent() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	

	
}
