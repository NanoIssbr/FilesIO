package fio;


import java.text.ParseException;

import org.apache.poi.ss.usermodel.Cell;
public class CellExcel {
	
	private Cell _cell;

	public Cell getCell() {
		return _cell;
	}
	
	public CellExcel(Cell _cell) {
		super();
		this._cell = _cell;
	}
	
	/**
	 * get value of the cell by type
	 * 
	 * @param String type
	 * @return Object 
	 * @throws ParseException 
	 */
	public Object getValueByType(String type) throws ParseException {
		switch (type) {
		case "double":
			return this._cell.getNumericCellValue();
		case "integer":
			return this._cell.getNumericCellValue();
		case "boolean":
			return this._cell.getBooleanCellValue();
		case "date":
			//DateFormat formatter = new DateFormat("yyyyMMdd");
			//return formatter.parse(formatter.format(this._cell.getDateCellValue()));
			return this._cell.getDateCellValue();
		case "string":
			return this._cell.getStringCellValue();
		default:
			return null;
		}
	}

}
