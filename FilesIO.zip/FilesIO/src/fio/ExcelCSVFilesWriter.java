package fio;

public class ExcelCSVFilesWriter extends AllFilesWriter{
	
	private static final String EXTENSION = "csv";
	
	public ExcelCSVFilesWriter(String fileName, String filePath) {
		super(fileName, filePath, EXTENSION);
	}

	@Override
	public void makeContentToWriteFile() {
		
		
	}

}
