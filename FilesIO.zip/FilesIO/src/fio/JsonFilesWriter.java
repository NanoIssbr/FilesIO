package fio;

public class JsonFilesWriter extends AllFilesWriter {

	private static final String EXTENSION = "json";

	public JsonFilesWriter(String fileName, String filePath) {
		super(fileName, filePath, EXTENSION);
	}
	
	public JsonFilesWriter(String fileName, String filePath, String contentToPrint) {
		super(fileName, filePath, EXTENSION, contentToPrint);
	}

	@Override
	public void makeContentToWriteFile() {
		
	}
}
