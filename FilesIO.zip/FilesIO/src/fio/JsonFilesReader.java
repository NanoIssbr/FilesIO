package fio;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import com.caciopee.genie.soa.client.result.BeanObject;
import com.caciopee.genie.works.business.utils.ServiceUtils;

public class JsonFilesReader implements FilesReader {

	private String pathToFile;
	private BufferedReader contentBuffered;
	
	public JsonFilesReader(String ptf) {
		this.pathToFile = ptf;
	}

	@Override
	public List<BeanObject> readContents() {
		System.out.println("read json file ["+this.pathToFile+"]");
		if(this.contentBuffered == null) {
			this.openFile();
		}
		System.out.println("read json file ["+this.pathToFile+"] => file opened");
        String line = "";
        StringBuffer content = new StringBuffer();
        //System.out.println("read json file ["+this.pathToFile+"] => numbre lines "+this.contentBuffered.lines().count());
        try {
            while ((line = this.contentBuffered.readLine()) != null) {
                content.append(line);
            }
        }catch(IOException e) {
            System.out.println(e.getMessage());
        }
        return ServiceUtils.jsonToListOfBeanObject(content.toString());
	}
	
	@Override
	public BeanObject readContent() {
		System.out.println("read json file ["+this.pathToFile+"]");
		if(this.contentBuffered == null) {
			this.openFile();
		}
		System.out.println("read json file ["+this.pathToFile+"] => file opened");
        String line = "";
        StringBuffer content = new StringBuffer();
        //System.out.println("read json file ["+this.pathToFile+"] => numbre lines "+this.contentBuffered.lines().count());
        try {
            while ((line = this.contentBuffered.readLine()) != null) {
                content.append(line);
            }
        }catch(IOException e) {
            System.out.println(e.getMessage());
        }
        return ServiceUtils.jsonToBeanObject(content.toString());
	}



	@Override
	public void openFile() {
        try {
            System.out.println("reading " + this.pathToFile + " file");
            File file = new File(this.pathToFile);
            this.contentBuffered = new BufferedReader(new FileReader(file));
            // contentJsonFile = new String(Files.readAllBytes(Paths.get(filePath)), StandardCharsets.UTF_8);
        } catch (IOException e) {
        	System.out.println("Cannot open Json file ["+this.pathToFile+"]");
            e.printStackTrace();
        }
	}

}
