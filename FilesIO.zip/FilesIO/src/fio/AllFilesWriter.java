package fio;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
/**
 * 
 * @author ibrayche
 *
 */
public class AllFilesWriter implements FilesWriter{

	private String fileName;
	private String filePath;
	private String completeFilePath;
	protected String contentToPrint;
	private static final boolean APPEND = true;
	private static final boolean AUTO_FLUSH = true;
	private static final String CHARSET = "UTF-8";

	public String getContentToPrint() {
		return contentToPrint;
	}

	public void setContentToPrint(String contentToPrint) {
		this.contentToPrint = contentToPrint;
	}

	/**
	 * write a file with {@link #contentToPrint} value
	 * @see #makeContentToWriteFile()
	 */
	@Override
	public void writeFile() throws FileNotFoundException, UnsupportedEncodingException, IOException {
		if(this.contentToPrint == null || this.contentToPrint.isEmpty()) {
			makeContentToWriteFile();
		}
//		System.out.println(this.contentToPrint);
		File file = new File(this.completeFilePath);
		PrintWriter pw = null;
		FileOutputStream fos = null;
		OutputStreamWriter osw = null;
		BufferedWriter bw = null;
		fos = new FileOutputStream(file, APPEND);
		osw = new OutputStreamWriter(fos, CHARSET);
		bw = new BufferedWriter(osw);
		pw = new PrintWriter(bw, AUTO_FLUSH);
		pw.write(this.contentToPrint);
		pw.close();
		bw.close();
		osw.close();
		fos.close();
	}

	/**
	 * @see {@link #com.cdlclassement.manipulatefiles.ExcelCSVFilesWriter.makeContentToWriteFile() ExcelCSVFilesWriter.makeContentToWriteFile()}
	 * @see {@link #com.cdlclassement.manipulatefiles.JsonFilesWriter.makeContentToWriteFile() makeContentToWriteFile.makeContentToWriteFile()}
	 */
	@Override
	public void makeContentToWriteFile() {
		
	}
	
	/**
	 * Default constructor
	 * @param fileName
	 * @param filePath
	 * @param extension
	 * @param resultBuilder
	 */
	public AllFilesWriter(String fileName, String filePath, String extension ) {
		this.fileName = fileName;
		this.filePath = filePath;
		this.completeFilePath = this.filePath + this.fileName + "." + extension;
	}
	
	public AllFilesWriter(String fileName, String filePath, String extension, String contentToPrint) {
		this.fileName = fileName;
		this.filePath = filePath;
		this.contentToPrint = contentToPrint;
		this.completeFilePath = this.filePath + this.fileName + "." + extension;
	}
	
	

}
