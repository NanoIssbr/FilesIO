package fio;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

public interface FilesWriter {
	public void writeFile() throws FileNotFoundException, UnsupportedEncodingException, IOException;
	public void makeContentToWriteFile();
	
}
