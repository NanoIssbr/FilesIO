package fio;

import java.util.List;

import com.caciopee.genie.soa.client.result.BeanObject;

public interface FilesReader {
	public static final String TYPE_FILE_JSON = "json";
	public static final String TYPE_FILE_EXCEL = "excel";
	public static final String PATHS_FILE_NAME = "paths";
	public static final String DOSSIERS_FILE_NAME = "dossiers";
	public static final String PRODUITS_FILE_NAME = "produits";
	public static final String ECHEANCES_FILE_NAME = "Echeances";
	public static final String STATUT_CLASSEMENT_FILE_NAME = "statutsClassement";
	public static final String ROOT_PATH = "";
	public static final String TEST1_FILE_NAME = "test1.xlsx";
	

	
	public List<BeanObject> readContents() throws Exception;
	public BeanObject readContent() throws Exception;
	public void openFile();
	
	
}
